<?php 
require_once "function.php";
session_start();

if (!$_SESSION["auth"]) {
    header("Location: " . "index.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="row-1">
        <?php require_once "template/navbar.php" ?>

            <div class="hero"></div>

            <div class="content">
                <h3 style="color: white">Daftar Produk Technopark Gallery SMKN 2 BANJARMASIN</h3>
                <div class="produk">
                    <?php $i = 0 ?>
                    <?php foreach($dataproduk as $data) : ?>
                        <div class="produk-loop">
                            <div class="card">
                                <img class="produkimg" src="<?= $data[3] ?>"></img>
                                <p><?= $data[0] ?></p>
                                <p><?= $data[1] ?></p>
                                <p>Rp.<?= $data[2] ?></p>
                            </div>
                            <a href="produk.php?id=<?= $i++ ?>" class="produk-btn">PILIH PRODUK</a>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
                <div class="row-2">
                    <?php require_once "template/footer.php" ?>
                </div></div>
    </div>
</body>
</html>