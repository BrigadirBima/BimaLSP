<footer class="footer">
    &copy;Copyright Bima Rizqy Prasurya <?= date("Y") ?>
</footer>