<?php 
//login function
function login() {
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = "userlsp"; //dummy untuk username
    $password = "smkn2bjm"; //dummy untuk password

    $enterUs = $_POST["username"]; //variable untuk mengambil username yang dimasukan di input name "username"
    $enterPass = $_POST["password"];//variable untuk mengambil password yang dimasukan di input name "password"

if($enterUs == $username && $enterPass == $password) { //jika input username dan password sama seperti variable $username dan $password
    $auth = $_SESSION["auth"] = "$username";
    setcookie("auth", $auth);
    header("location: home.php"); //maka akan dipindahkan ke halaman home.php
    exit(); 
} else { //dan jika username dan password yang dimasukan tidak sama
    echo'<script language="javascript">'; //maka akan ditampilkan tulisan ini
    echo 'alert("Username dan password anda salah")';
    echo '</script>';
}}}
//end login function

//home function

$dataproduk = array (
    array("PAKAN IKAN OTOMATIS", "Beri makan ikan tanpa repot dengan pakan ikan otomatis produk dari jurusan RPL",100000,"img/ikan.jpg"),
    array("WEBSITE COMPANY PROFILE", "Zaman now masih belum punya website percayakan pembuatan website pada kula koding smkn 2 banjarmasin",45000,"img/website.png"),
    array("KURSI JATI", "Kursi estetik dengan bahan jati dibuat oleh jurusan Teknik Furniture",50000,"img/kursi.jpeg"),
    array("SABUN LAUNDRY", "Mewangikan pakaian menggunakan bahan yang aman untuk pakaian, produksi dari jurusan Kimia Industri",55000,"img/laundry.jpg")
   );
//end home function

function logout() {
    echo "<script>alert('s')</script>";
    session_start();
    setcookie("auth", "", 100);
    session_unset();
    session_destroy();

    header("Location: " . "index
    .php");
}
?>