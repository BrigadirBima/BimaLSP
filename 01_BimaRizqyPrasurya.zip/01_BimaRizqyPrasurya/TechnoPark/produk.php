<?php 
require_once "function.php"; //untuk menyambungkan php ke function.php
session_start();

if (!$_SESSION["auth"]) {
    header("Location: " . "index.php");
}
$id = $_GET["id"]; //mengambil methode get dari id untuk disimpat di $id
$data = $dataproduk[$id]; //memasukan data array yang sudah berisi $id di dalamnya kedalam $data untuk nanti diambil kembali agar dapat menampilkan array di perulangan
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="row-1">
        <?php require_once "template/navbar.php" ?>
            <div class="detail">
                <div class="">
                    <div class="detail-flex">
                        <label for="no">No Transaksi</label>
                        <input type="number" name="no" id="no">
                    </div>
                    <div class="detail-flex">
                        <label for="tanggal">Tanggal Transaksi</label>
                        <input type="date" name="tanggal" id="tanggal">
                    </div>
                    <div class="detail-flex">
                        <label for="nama">Nama Customer</label>
                        <input type="text" name="nama" id="nama">
                    </div>
                    <div class="detail-flex">
                        <label for="produk">Pilihan produk:</label>
                        <input type="text" id="produk" name="produk" value="<?= htmlspecialchars($data[0])?>" readonly>
                    </div>
                    <div class="detail-flex">
                        <label for="harga">harga produk</label>
                        <input type="text" id="harga" name="harga" value="<?= htmlspecialchars($data[2]) ?>" readonly>
                    </div>
                    <div class="detail-flex">
                        <label for="produk">Jumlah Produk</label>
                        <input type="number" name="produk" id="pdk" value="1" required>
                    </div>
                </div>
                <div class="right">
                    <div class="">
                        <button id="total" name="total" class="btn">Hitung Harga total</button>
                    </div>
                </div>
            </div>
                <div class="harga">
                    <div class="row-1">
                    <div class="">
                        <label for="total">Total Harga</label>
                        <input type="text" name="total" id="total" class="total" readonly>
                    </div>
                    <div class="">
                        <label for="total">Pembayaran</label>
                        <input id="pembayaran" type="text" name="pembayaran">
                    </div>
                <button id="kembalian" class="transkasi-btn">Hitung Kembalian</button>
                </div>
                <div class="harga">
                    <div class="row-1">
                    <div class="">
                        <label for="total">Kembalian</label>
                        <input type="text" name="totalkembalian" id="totalkembalian" readonly>
                    </div>
                    <div class="">
                    <button id="simpan" class="transkasi-btn">Simpan Transaksi</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="row-2">
                <?php require_once "template/footer.php" ?>
        </div>
       <script>//ini adalah variable yang diambil dari id="" pada html diatas lalu dimasukan ke dalam variable agar dijadikan fungsi
            const jumlahbtn = document.getElementById("total"); 

            const jumlahbrg = document.querySelector(".total");
            
            const jumlahpdk = document.getElementById("pdk");
            
            const hargabrg = document.querySelector("#harga");
            
            const bayarbrg = document.getElementById("pembayaran");
            
            const kembalianBtn = document.getElementById("kembalian");
            
            const totalkembalian = document.getElementById("totalkembalian");
            
            const simpanBtn = document.getElementById("simpan");

            let total;
     
        jumlahbtn.addEventListener("mousedown",() => { //menambahkan event pada button id="total"
            total = parseInt(hargabrg.value) * parseInt(jumlahpdk.value);//harga produk dikalikan dengan jumlah produk yang ingin dibeli
            jumlahbrg.value = total; //value dari jumlah barang adalah total dari perhitungan diatas
            return total; //mengembalikan nilai total
            });
     
        kembalianBtn.addEventListener("mousedown",() => { //membuat fungsi pada button kembalian
                totalkembalian.value = parseInt(bayarbrg.value) - parseInt(total) ; //total kembalian diambil dari semua dari total harga barang dengan pelembut maupun tidak lalu dikurangi dengan uang costomer
        });

        simpanBtn.addEventListener("mousedown",() => { //membuat fungsi pada button simpan
            alert('Data Berhasil Disimpan'); //jika tombol dipencet maka akan mengelurakan pop up ini
            window.location.href = "home.php"; //lalu user akan dikembalikan ke halaman admin
            });
     </script>
</body>
</html>